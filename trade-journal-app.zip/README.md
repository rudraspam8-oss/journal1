# Trade Journal

Dark-mode trading journal. Frontend in `public/index.html`, backend in `src/index.js` (Cloudflare Worker + KV storage).

## Deploy from PowerShell (fastest)
Install Node.js first, then inside this folder:

    npx wrangler login
    npx wrangler deploy

It prints your link, like https://trade-journal.YOURNAME.workers.dev
(The KV storage is created automatically. If wrangler asks for a KV id, run
`npx wrangler kv namespace create JOURNAL` and paste the id into wrangler.jsonc.)

## Deploy from GitHub
1. Push this folder to a GitHub repo.
2. Cloudflare dashboard > Workers & Pages > Create > Import a repository.
3. Leave the build command empty, deploy command `npx wrangler deploy`. Save and deploy.

## Run locally
    npm install
    npm run dev

## Notes
- Users log in with any username, no password. Add real auth in `src/index.js` before storing sensitive data.
- API: GET/PUT /api/journal/<username>/<key> for keys tj_trades_v1, tj_days_v1, tj_goal, tj_bal.
