// Trade Journal backend: stores each user's data in Cloudflare KV.
// Routes: GET/PUT /api/journal/<username>/<key>
const MAX = 2 * 1024 * 1024; // 2 MB per value

const json = (data, status = 200) =>
  new Response(typeof data === "string" ? data : JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const m = url.pathname.match(/^\/api\/journal\/([a-z0-9_.@-]{1,40})\/(tj_[a-z0-9_]{1,30})$/);
    if (!m) return json({ error: "Not found" }, 404);
    const kvKey = `${m[1]}:${m[2]}`;

    if (req.method === "GET") {
      const v = await env.JOURNAL.get(kvKey);
      return json(v === null ? "null" : v);
    }
    if (req.method === "PUT") {
      const body = await req.text();
      if (body.length > MAX) return json({ error: "Too large" }, 413);
      try { JSON.parse(body); } catch { return json({ error: "Invalid JSON" }, 400); }
      await env.JOURNAL.put(kvKey, body);
      return json({ ok: true });
    }
    return json({ error: "Method not allowed" }, 405);
  },
};
